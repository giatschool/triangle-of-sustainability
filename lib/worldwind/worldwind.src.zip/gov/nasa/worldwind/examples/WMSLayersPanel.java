/*
Copyright (C) 2001, 2006 United States Government
as represented by the Administrator of the
National Aeronautics and Space Administration.
All Rights Reserved.
*/
package gov.nasa.worldwind.examples;

import gov.nasa.worldwind.WorldWindow;
import gov.nasa.worldwind.avlist.*;
import gov.nasa.worldwind.layers.*;
import gov.nasa.worldwind.wms.*;
import org.w3c.dom.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.xml.parsers.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;

/**
 * @author tag
 * @version $Id: WMSLayersPanel.java 2471 2007-07-31 21:50:57Z tgaskins $
 */
public class WMSLayersPanel extends JPanel
{
    private final WorldWindow wwd;
    private final URI serverURI;
    private final Dimension size;
    private final LayerList layerList = new LayerList();
    private final Thread loadingThread;
    private Capabilities caps;

    public WMSLayersPanel(WorldWindow wwd, String server, Dimension size) throws URISyntaxException
    {
        super(new BorderLayout());

        // See if the server name is a valid URI. Throw an exception if not.
        this.serverURI = new URI(server.trim()); // throws an exception if server name is not a valid uri.

        this.wwd = wwd;
        this.size = size;
        this.setPreferredSize(this.size);

        this.makeProgressPanel();

        // Thread off a retrieval of the server's capabilities document and update of this panel.
        this.loadingThread = new Thread(new Runnable()
        {
            public void run()
            {
                load();
            }
        });
        this.loadingThread.start();
    }

    private void load()
    {
        try
        {
            // Retrieve the server's capabilities document and parse it into a DOM.
            // Set up the DOM.
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            docBuilderFactory.setNamespaceAware(true);
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc;

            // Request the capabilities document from the server.
            CapabilitiesRequest req = new CapabilitiesRequest(serverURI);
            doc = docBuilder.parse(req.toString());

            // Parse the DOM as a capabilities document.
            this.caps = Capabilities.parse(doc);
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return;
        }

        // Gather up all the named layers and make a world wind layer for each.
        final Element[] namedLayers = WMSLayersPanel.this.caps.getNamedLayers();
        if (namedLayers == null)
            return;

        try
        {
            for (Element layerCaps : namedLayers)
            {
                Element[] styles = caps.getLayerStyles(layerCaps);
                if (styles == null)
                {
                    Layer layer = createLayer(WMSLayersPanel.this.caps, layerCaps, null);
                    WMSLayersPanel.this.layerList.add(layer);
                }
                else
                {
                    for (Element style : styles)
                    {
                        Layer layer = createLayer(WMSLayersPanel.this.caps, layerCaps, style);
                        WMSLayersPanel.this.layerList.add(layer);
                    }
                }
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            return;
        }

        // Fill the panel with the layer titles.
        EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                WMSLayersPanel.this.removeAll();
                makeLayersPanel(layerList);
            }
        });
    }

    public LayerList getLayerList()
    {
        return this.layerList;
    }

    public Capabilities getCaps()
    {
        return this.caps;
    }

    private void makeProgressPanel()
    {
        // Create the panel holding the progress bar during loading.

        JPanel outerPanel = new JPanel(new BorderLayout());
        outerPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        outerPanel.setPreferredSize(this.size);

        JPanel innerPanel = new JPanel(new BorderLayout());
        innerPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        JProgressBar progressBar = new JProgressBar();
        progressBar.setIndeterminate(true);
        innerPanel.add(progressBar, BorderLayout.CENTER);

        JButton cancelButton = new JButton("Cancel");
        innerPanel.add(cancelButton, BorderLayout.EAST);
        cancelButton.addActionListener(new AbstractAction()
        {
            public void actionPerformed(ActionEvent actionEvent)
            {
                if (loadingThread.isAlive())
                    loadingThread.interrupt();

                Container c = WMSLayersPanel.this.getParent();
                c.remove(WMSLayersPanel.this);
            }
        });

        outerPanel.add(innerPanel, BorderLayout.NORTH);
        this.add(outerPanel, BorderLayout.CENTER);
        this.revalidate();
    }

    private void makeLayersPanel(LayerList layerList)
    {
        // Create the panel holding the layer names.
        JPanel layersPanel = new JPanel(new GridLayout(0, 1, 0, 15));
        layersPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        // Add the server's layers to the panel.
        for (Layer layer : layerList)
        {
            addLayerToPanel(layersPanel, WMSLayersPanel.this.wwd, layer);
        }

        // Put the name panel in a scroll bar.
        JScrollPane scrollPane = new JScrollPane(layersPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        scrollPane.setPreferredSize(size);

        // Add the scroll bar and name panel to a titled panel that will resize with the main window.
        JPanel westPanel = new JPanel(new GridLayout(0, 1, 0, 10));
        westPanel.setBorder(
            new CompoundBorder(BorderFactory.createEmptyBorder(9, 9, 9, 9), new TitledBorder("Layers")));
        westPanel.add(scrollPane);
        this.add(westPanel, BorderLayout.CENTER);

        this.revalidate();
    }

    public String getServerDisplayString()
    {
        // Find the best available name for the server.

        if (caps == null)
        {
            // Capabilities have not yet been retrieved, so use the host name of the server's URI.
            return this.serverURI.getHost();
        }

        if (this.caps.getTitle() != null && this.caps.getTitle().length() > 0)
            return this.caps.getTitle();

        if (this.caps.getName() != null && this.caps.getName().length() > 0)
            return this.caps.getName();

        return null;
    }

    private Layer createLayer(Capabilities caps, Element layerCaps, Element style)
    {
        // Create the layer specified by the layer's capabilities entry and the selected style.

        AVListImpl params = new AVListImpl();
        params.setValue(AVKey.LAYER_NAMES, caps.getLayerName(layerCaps));
        if (style != null)
            params.setValue(AVKey.STYLE_NAMES, caps.getStyleName(style));

        Layer layer = WMSLayerFactory.newLayer(caps, params);
        layer.setEnabled(false);

        // Some wms servers are slow, so increase the timeouts and limits used by world wind's retrievers.
        layer.setValue(AVKey.URL_CONNECT_TIMEOUT, 30000);
        layer.setValue(AVKey.URL_READ_TIMEOUT, 30000);
        layer.setValue(AVKey.RETRIEVAL_QUEUE_STALE_REQUEST_LIMIT, 60000);

        return layer;
    }

    private void addLayerToPanel(JPanel layersPanel, WorldWindow wwd, Layer layer)
    {
        // Give a layer a button and label and add it to the layer names panel.

        LayerAction action = new LayerAction(layer, wwd);
        JCheckBox jcb = new JCheckBox(action);
        jcb.setSelected(layer.isEnabled());
        layersPanel.add(jcb);
    }

    private class LayerAction extends AbstractAction
    {
        private WorldWindow wwd;
        private Layer layer;

        public LayerAction(Layer layer, WorldWindow wwd)
        {
            // Capture info we'll need later to control the layer.
            super(layer.getName());
            this.wwd = wwd;
            this.layer = layer;

            // Add the layer to the world window model's layer list if the layer is enabled.
            if (layer.isEnabled())
            {
                ApplicationTemplate.insertBeforePlacenames(this.wwd, this.layer);
            }
        }

        public void actionPerformed(ActionEvent actionEvent)
        {
            // If the layer is selected, add it to the world window's current model, else remove it from the model.
            if (((JCheckBox) actionEvent.getSource()).isSelected())
            {
                this.layer.setEnabled(true);
                ApplicationTemplate.insertBeforePlacenames(this.wwd, this.layer);
                WMSLayersPanel.this.firePropertyChange("LayersPanelUpdated", null, layer);
            }
            else
            {
                this.layer.setEnabled(false);
                this.wwd.getModel().getLayers().remove(layer);
                WMSLayersPanel.this.firePropertyChange("LayersPanelUpdated", layer, null);
            }

            // Tell the world window to update.
            wwd.redraw();
        }
    }
}
