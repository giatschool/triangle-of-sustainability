/*
Copyright (C) 2001, 2006 United States Government as represented by
the Administrator of the National Aeronautics and Space Administration.
All Rights Reserved.
*/
package gov.nasa.worldwind.pick;

import gov.nasa.worldwind.geom.Position;
import gov.nasa.worldwind.render.WWIcon;

import java.awt.*;

/**
 * @author dcollins
 * @version $Id: PlaceName.java 2471 2007-07-31 21:50:57Z tgaskins $
 */
public interface PlaceName
{
    String getText();

    void setText(String text);

    Position getPosition();

    void setPosition(Position position);

    Font getFont();

    void setFont(Font font);

    Color getColor();

    void setColor(Color color);

    boolean isVisible();

    void setVisible(boolean visible);

    WWIcon getIcon();

    void setIcon(WWIcon icon);
}
